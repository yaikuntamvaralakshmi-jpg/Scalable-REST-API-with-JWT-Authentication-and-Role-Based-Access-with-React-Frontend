import React, { useState } from 'react';
import { login } from '../services/api';

export default function Login({ setToken }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await login({ email, password });
    setToken(res.data.token);
    localStorage.setItem('token', res.data.token);
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder='Email' value={email} onChange={e => setEmail(e.target.value)} />
      <input placeholder='Password' type='password' value={password} onChange={e => setPassword(e.target.value)} />
      <button>Login</button>
    </form>
  );
}
