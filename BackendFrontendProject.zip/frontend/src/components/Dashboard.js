import React, { useEffect, useState } from 'react';
import { getTasks } from '../services/api';

export default function Dashboard({ token }) {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    const fetchTasks = async () => {
      const res = await getTasks(token);
      setTasks(res.data);
    };
    fetchTasks();
  }, [token]);

  return (
    <div>
      <h1>Dashboard</h1>
      {tasks.map(task => <div key={task._id}>{task.title}</div>)}
    </div>
  );
}
